class task:
  
  def __init__(self, desc, date, time):
    """#initializes task object, desc is the description of the task, date/time is the deadline of the task"""
    self._desc = desc
    self._date = date
    self._time = time
    self._time = self._time.strip("\n")

  def __str__(self): 
    """#string output when called: "Task due 01/01/2000 at 00:00"""
    return self._desc + " - Due: " + self._date + " at " + self._time

  def __repr__(self): 
    """#string format for task item"""
    return self._desc + "," + self._date+","+self._time

  def __lt__(self, other): 
    """#splits the date and time into comparable components"""
    date1 = self._date.split("/")
    date2 = other._date.split("/")
    time1 = self._time.split(":")
    time2 = other._time.split(":")


    #conditions for if self is less than other, returns a boolean
    if date1[2] > date2[2]:
      #print("F:year")
      return False
    elif date1[2] < date2[2]:
      #print("T:year")
      return True
    elif date1[0] > date2[0]:
      #print("F:month")
      return False
    elif date1[0] < date2[0]:
      #print("T:month")
      return True
    elif date1[1] > date2[1]:
      #print("F:day")
      return False
    elif date1[1] < date2[1]:
      #print("T:day")
      return True 
    elif time1[0] > time2[0]:
      #print("F:hour")
      return False
    elif time1[0] < time2[0]:
      #print("T:hour")
      return True  
    elif time1[1] > time2[1]:
      #print("F:min")
      return False
    elif time1[1] < time2[1]:
      #print("T:min")
      return True
    elif self._desc > other.desc:
      #print("F:name")
      return False
    elif self._desc < other.desc:
      #print("name")
      return True

  @property
  def date(self):
    return(self._date)

    