#Names: Christopher Garibay & Tiffany Lin
#Date: 11 Nov. 2023 - Lab 13
#Desc: A program that enables the user to have a functional tasklist. The user can add, delete, and display tasks. Lab 13 modifies the tasklist program to use an iterator structure.

import tasklist
import check_input as ci


def main():
  list = tasklist.tasklist()

  def main_menu():
    #display menu that shows all the options of the task program
    print("\n-Tasklist-")
    print("Tasks to complete: " + str(len(list)))
    print("1. Display current task")
    print("2. Display all tasks")
    print("3. Mark current task complete")
    print("4. Add new task")
    print("5. Search by Date")
    print("6. Save and quit")
    choice = ci.get_int_range("Enter choice: ", 1, 6)
    return choice

  def get_date():
    """if the user wants to add a task, they have to give a date"""
    month = ci.get_int_range("Enter month: ", 1, 12)
    if month < 10:  #conditional to add a 0 to the string if the month < 10
      month = "0" + str(month)
    day = ci.get_int_range("Enter day: ", 1,
                           31)  #actual days/month are ignored eg. February
    if day < 10:
      day = "0" + str(day)
    year = ci.get_int_range("Enter year: ", 2000, 3000)
    return str(month) + "/" + str(day) + "/" + str(
        year)  #returns the date in format 01/31/2000

  def get_time():  
    """if the user wants to add a task, they have to give a time"""
    print("Enter time:")
    hour = ci.get_int_range("Enter hour: ", 0, 23)
    if hour < 10:  #conditional for an appropriate string
      hour = "0" + str(hour)
    minute = ci.get_int_range("Enter minute: ", 0, 59)
    if minute < 10:
      minute = "0" + str(minute)
    return str(hour) + ":" + str(minute)  #returns time in format 00:00

  while True:  #conditional for loop of task program to user
    choice = main_menu()
    print()
    if choice == 1:  #displays current task
      if len(list) == 0:
        print("You have no tasks at this time")
        continue
      print("Current task is:")
      print(list.get_current_task())

    elif choice == 2:  #displays all the task in tasklist
      if len(list) == 0:
        print("You have no tasks at this time")
        continue
      print("Tasks:")
      for i in list:

        print(i)

    elif choice == 3:
      #Displays the current task, removes it, and then displays the new current task by calling Tasklist’s mark_complete method. If there are no tasks, then display a message.
      
      if len(list) == 0:
        print("You have no tasks at this time")
        continue
      print("Marking current task as complete:")
      print(list.get_current_task())
      list.mark_complete()

      print("New current task is:")
      print(list.get_current_task())

    elif choice == 4:  
      #if user wants to add a new task to tasklist
      task = input("Enter a task: ")
      print("Enter due date:")
      date = get_date()
      time = get_time()
      list.add_task(task, date, time)

    elif choice == 5:
      
      print("Enter date to search: ")
      date = get_date()
      search_list = []
      for n in list:
        if n.date == date:
          search_list.append(n)
      search_list.sort()
      print("Tasks due on ", str(date), ":")
      for x in search_list:
        print(x)

      #Prompts the user to enter a date (MM/DD/YYYY). Use the iterator to loop through the list, if the task’s date is the same as the user’s, then display the task. It should display all tasks with the matching date (not just the first one)

    elif choice == 6:  #saves and quits program
      list.save_file()
      break


main()
