import task
class tasklist:
  def __init__(self):
    """#initializes tasklist as a list"""
    self._tasklist = [] 
    
    file = open("tasklist-1.txt") #opens txt file and stores all lines as a item in list
    tasks = file.readlines()
    
    for i in tasks:
      i.replace("\n","")
      properties = i.split(",")
      dsc = properties[0]
      date = properties[1]
      time = properties[2]
      self._tasklist.append(task.task(dsc,date,time))
    file.close()

    # sorts tasklist items by date and time then aplhabetical order.
    self._tasklist.sort()

  def add_task(self, desc, date, time): #unchanged
    """#adds the new task to the tasklist"""
    self._tasklist.append(task.task(desc,date,time))

    #sorting algorithim after new task is added to tasklist
    self._tasklist.sort()

  def mark_complete(self): #unchanged
    """ #removes current task bc it is completed"""
    self._tasklist.pop(0) 

  def save_file(self):
    """#saves everything in the txt file; "overwriting"""
    file = open("tasklist-1.txt", "w")
    for i in self._tasklist:
      string = repr(i)
      file.write(string + "\n")
    file.close()

  def __getitem__(self, index):
    """#returns item from tasklist at specific index"""
    return self._tasklist[index]

  def get_current_task(self):
    """#return the first task object."""
    try:
    	return self._tasklist[0]
    except IndexError:
      return None
    
  def __len__(self):
    """#returns length of tasklist"""
    return len(self._tasklist)

  def __iter__(self):
    """#initialize the iterator attribute (n) and return self."""
    self._n = -1 
    return self
    
  def __next__(self):
    "Iterates through one increment of the tasklist"
    self._n += 1
    if self._n >= len(self._tasklist):
        raise StopIteration
    else:
        return self._tasklist[self._n]

    #iterate the iterator one position at a time. Raise a StopIteration when the iterator reaches the end of the tasklist, otherwise return the Task object at the iterator’s current position
    

    

    
    